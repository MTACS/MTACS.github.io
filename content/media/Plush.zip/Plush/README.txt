Hello!

First of all, I apologize ThemeKit is not available as a standalone app quite yet. I have had school and it has slowed my progress. Until then use LiteIcon - https://freemacsoft.net/downloads/LiteIcon_3.7.1.zip

1. Disable SIP, reboot Mac and hold Command+R at boot. When the window appears, go to Utilities>Terminal and type "csrutil disable" without the quotes. Then type reboot

2. Open LiteIcon and drag each icon individually to change. ThemeKit will support icon packs where you click one to apply the whole thing.

3. If you use the icons given "Plush" please just give me credit, it's all I ask.

4. Enjoy (hopefully) :)
