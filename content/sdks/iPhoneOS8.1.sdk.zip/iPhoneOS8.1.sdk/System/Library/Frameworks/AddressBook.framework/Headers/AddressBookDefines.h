//
//  AddressBookDefines.h
//  AddressBook
//
//  Copyright (c) 2012 Apple Inc. All rights reserved.
//

#ifndef AddressBook_AddressBookDefines_h
#define AddressBook_AddressBookDefines_h

#ifdef __cplusplus
#define AB_EXTERN		extern "C" __attribute__((visibility ("default")))
#else
#define AB_EXTERN	        extern __attribute__((visibility ("default")))
#endif

#endif
