/*
    File: AdSupport.h
 
    Framework: AdSupport
 
    Copyright (c) 2012, Apple Inc. All rights reserved.
*/

#ifndef AdSupport_AdSupport_h
#define AdSupport_AdSupport_h

#import <AdSupport/ASIdentifierManager.h>

#endif